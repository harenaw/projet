import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router'
import LoginComponent from '@/views/LoginComponent.vue'
import UserComponent from '@/views/UserComponent.vue'
import AddUserComponent from '@/views/AddUserComponent.vue'
import authService from '@/services/authService'

const routes: Array<RouteRecordRaw> = [
  {path: '/login', component: LoginComponent, meta: { requiresAuth: false }},
  {path: '/users', component: UserComponent, meta: { requiresAuth: true }},
  {path: '/ajouter-utilisateur', component: AddUserComponent, meta: { requiresAuth: true }},
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

router.beforeEach((to, from, next) => {
  if (to.meta.requiresAuth && !authService.isAuthenticated()) {
    // Redirect to the login page if authentication is required but the user is not authenticated
    next('/login');
  } else if (!to.meta.requiresAuth && authService.isAuthenticated()) {
    // Redirect away from the login page if the user is already authenticated
    next('/users');
  } else {
    next();
  }
});

export default router
