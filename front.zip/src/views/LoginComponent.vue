/* eslint-disable */
<template>
  <div class="container">
    <div class="row">
      <main class="form-signin">
        <form @submit.prevent="onLogin">
          <div class="form-group">
            <label for="exampleInputEmail1">Adresse email</label>
            <input
              v-model="email"
              type="email"
              class="form-control"
              id="exampleInputEmail1"
              aria-describedby="emailHelp"
              placeholder="Enter email"
            />
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input
              v-model="password"
              type="password"
              class="form-control"
              id="exampleInputPassword1"
              placeholder="Password"
            />
          </div>
          <button type="submit" class="btn btn-primary">Se connecter</button>
        </form>
      </main>
    </div>
  </div>
</template>

<script lang="ts">
import authService from "@/services/authService";
import axios from "axios";
import { toast } from "vue3-toastify";

import "vue3-toastify/dist/index.css";

axios.defaults.headers.common["Content-Type"] = "application/json";

export default {
  name: "LoginComponent",

  data() {
    return { email: "", password: "" };
  },
  methods: {
    onLogin() {
      authService
        .login(this.email, this.password)
        .then(() => window.location.reload())
        .catch(() =>
          toast.error("Adresse email ou mot de passe incorrecte", {
            autoClose: 1000,
          })
        );
    },
  },
};
</script>

<style>
.form-signin {
  max-width: 330px;
  padding: 1rem;
}

.form-signin .form-floating:focus-within {
  z-index: 2;
}

.form-signin input[type="email"] {
  margin-bottom: -1px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}

.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
</style>
