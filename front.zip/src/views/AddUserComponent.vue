<template>
  <ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link active" href="#">Utilisateurs</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Courriers</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Entités</a>
    </li>
  </ul>
  <div class="container">
    <div class="row">
      <form>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputEmail4">Email</label>
            <input
              type="email"
              class="form-control"
              id="inputEmail4"
              placeholder="Email"
              required
            />
          </div>
          <div class="form-group col-md-6">
            <label for="inputEmail4">Prénom</label>
            <input
              type="text"
              class="form-control"
              id="inputEmail4"
              placeholder="Prénom"
              required
            />
          </div>
          <div class="form-group col-md-6">
            <label for="inputEmail4">Nom</label>
            <input
              type="text"
              class="form-control"
              id="inputEmail4"
              placeholder="Nom"
              required
            />
          </div>
          <div class="form-group col-md-6">
            <label for="inputEmail4">Mot de passe</label>
            <input
              type="password"
              class="form-control"
              id="inputEmail4"
              placeholder="Mot de passe"
              required
            />
          </div>
          <div class="form-group col-md-6">
            <label for="inputEmail4">Rôle</label>
            <select class="form-control" name="role" id="role">
                <option value="dof">DOF</option>
                <option value="dg">DOF</option>
                <option value="secretary">Sécretaire</option>
            </select>
          </div>
        </div>

        <button type="submit" class="btn btn-primary">Sign in</button>
      </form>
    </div>
  </div>
</template>

<script lang="ts">
export default {
  name: "AddUserComponent",
};
</script>
