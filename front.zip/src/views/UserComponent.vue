<template>
  <ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link active" href="#">Utilisateurs</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Courriers</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Entités</a>
    </li>
  </ul>
  <div class="container">
    <div class="row">
      <div class="contents">
        <a href="/ajouter-utilisateur" type="button" class="btn btn-primary action-button">
          Ajouter utilisateur
        </a>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Prénom</th>
              <th scope="col">Nom</th>
              <th scope="col">Role</th>
              <th scope="col">Email</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="user in userList" :key="user.id">
              <th scope="row">{{ user.id }}</th>
              <td>{{ user.firstname }}</td>
              <td>{{ user.lastname }}</td>
              <td>{{ user.role }}</td>
              <td>{{ user.email }}</td>
              <td>
                <button type="button" class="btn btn-primary action-button">
                  Détails
                </button>
                <button type="button" class="btn btn-success action-button">
                  Modifier
                </button>
                <button type="button" class="btn btn-danger">Supprimer</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>
<style>
.contents {
  margin-top: 50px !important;
}

.action-button {
  margin-right: 5px;
}
</style>
<script lang="ts">
import userService from "@/services/userService";
export default {
  name: "UserComponent",
  data() {
    return {
      userList: [],
    };
  },
  mounted() {
    // Call a method to fetch the items when the component is mounted
    this.fetchItems();
  },
  methods: {
    fetchItems() {
      userService.fetchUser().then((data) => {
        this.userList = data;
      });
    },
  },
};
</script>
