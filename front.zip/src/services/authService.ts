import { API_URL } from '@/config';
import axios from 'axios';

const TOKEN_KEY = 'access_token';

const authService = {
  login: async (email, password) => {
    try {
      const response = await axios.post(`${API_URL}/login`, { email, password });
      const token = response.data.access_token;

      localStorage.setItem(TOKEN_KEY, token);
      return token;
    } catch (error) {
      throw new Error('Login failed');
    }
  },
  logout: () => {
    localStorage.removeItem(TOKEN_KEY);
  },
  isAuthenticated: () => {
    return localStorage.getItem(TOKEN_KEY) !== null;
  },
  getToken: () => {
    return localStorage.getItem(TOKEN_KEY);
  },
};

export default authService;