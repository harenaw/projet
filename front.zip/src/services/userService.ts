import { API_URL } from '@/config';
import axios from 'axios';

const TOKEN_KEY = localStorage.getItem('access_token');

const userService = {
  fetchUser: async () => {
    try {
      const response = await axios.get(`${API_URL}/users`, {headers: {Authorization: `Bearer ${TOKEN_KEY}`}});
      const data = response.data.data;

      return data;
    } catch (error) {
      throw new Error('Login failed');
    }
  }
};

export default userService;